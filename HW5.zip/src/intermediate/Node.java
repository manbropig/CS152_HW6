/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package intermediate;

/**
 *
 * @author jamie
 */
public class Node 
{
    public Node leftChild;
    public Node rightChild;
    public Node parent;
    public String token;
    public boolean flag;
    public Node ()
    {
        this.flag = false;
    }
    public Node(String tok) 
    {
        this.token = tok;
    }

    public String toString() {

        if(leftChild == null && rightChild == null)
            return token;
        else
            return "--";

    }
}
