/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package intermediate;

import backend.Executor;
import frontend.Scheme_Parser;
import java.util.ArrayList;

/**
 *
 * @author jamie
 */
public class ParseTree {

    Scheme_Parser parser;
    int index;
    public ArrayList<Node> roots;
    public Executor executor;
    public ArrayList<String> tokens;
    
    public ParseTree(Scheme_Parser parser, ArrayList<String> tokens)
    {
        this.parser = parser;
        roots = new ArrayList<Node>();
        index = 0;
        this.tokens = tokens;
        executor = new Executor(this);
        
        
        
//        while(index < size)
//            this.buildTree(tokens);
        
        
    }
    
    public void buildSelf()
    {
        int size = tokens.size();
        int start = 0;
        int end = 0;
        while(index < size)
            this.buildTree(tokens, start, end);
    }
    
    
    
    /**
     * Useless waste of time!!! DONT USE THIS
     * @param tokens
     * @param current
     * @param i
     * @return 
     */
    public void buildTree(ArrayList<String> tokens, int start, int end)
    {
        Node root = new Node();
        
        //int size = tokens.size();
        root = new Node();
        Node current = root;
        
        root.flag = true; //any node with flag = true means beginning of a list
        int size = tokens.size();
        
        //root = buildTree(tokens, root, 0);
        for (; index < size; index++)
        {   
            String token = tokens.get(index);
            //String token = tokens.get(i);
            Node parent;

            if (token.equals("(")) //probably need to flag this node somehow
            {
                //skip this step for beginning of first list
                if(current == root) continue;
                
                current.flag = true;//mark this flag as beginning of a new list
                current.leftChild = new Node();
//              
                current.leftChild.parent = current;
//              
                current = current.leftChild;
            }
            else if(token.equals(")"))
            {
                while(!current.flag)
                {
                    current = current.parent;
                }
                current.flag  = false;
                if(current.parent == null)//if reach end of top level list
                {
                    ++index;
                    ArrayList tok = subArray(tokens, start, index);
                    this.parser.buildSymTab(tok);
                    System.out.printf("\n********PRINTING SYMBOL TABLE********\n");
                    executor.printSymTab();
                    System.out.println("\n********PRINTING TREE********\n");
                    executor.printTree(this, current);
                    this.parser.clearIntCode(current);
                    this.parser.clearSymTab();
                    
                    return;
                }
                if(index+1 < size)
                {
                    if(!tokens.get(index + 1).equals(")"))
                    {
                        current.rightChild = new Node();
                        current.rightChild.parent = current;
                        current = current.rightChild;
                    }
                    
                }
                
                
            }
            else 
            {
                //if token is a word
                //create left node and place token there
                //then create right node and make it current node
                current.leftChild = new Node();
                current.leftChild.token = token;
                current.leftChild.parent = current;
                
                if((tokens.get(index+1)).equals(")")) 
                    continue;
                
                //before doing this, check if next token is ")"
                //if it is, don't do this!
                //instead travers back up until you see the flagged node
                current.rightChild = new Node();
                current.rightChild.parent = current;
                current = current.rightChild;
            }
        }
        //return root;
    }

    //    public Node getRoot() 
    //    {
    //        return this.root;
    //    }
    
    public void preorderTraverseTree(Node currentNode) {

        if (currentNode != null) 
        {
            System.out.println(currentNode);
            preorderTraverseTree(currentNode.leftChild);
            preorderTraverseTree(currentNode.rightChild);
        }
    }

    private ArrayList<String> 
            subArray(ArrayList<String> tokens,int start, int end)
    {
        ArrayList tok = new ArrayList(end - start);
        for(int i = 0; i < index; i++)
        {
            tok.add(tokens.get(start++));
        }
        return tok;
        
    }
    

}
//
//class Node 
//{
//    Node leftChild;
//    Node rightChild;
//    Node parent;
//    String token;
//    boolean flag = false;
////    Node() 
////    {
////        
////    }
//
//    public String toString() {
//
//        if(leftChild == null && rightChild == null)
//            return token;
//        else
//            return "--";
//
//    }
//}


